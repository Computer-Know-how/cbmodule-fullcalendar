Full Calendar Module
=================

Author
-----------------
Computer Know How/Mark Skelton

Summary
-----------------
A module that adds calendars to your ContentBox pages.

Summary
-----------------
This module will allow you to create calendars and display them on your ContentBox pages.  You can use Google Calendars or create your calendar and add events through the ContentBox admin.  Calendars are added to the page by clicking the "Insert a ContentBox Widget" button in the CKEditor and choosing the FullCalendar widget.

Install Instructions
-----------------
Download code and extract it to your ContentBox modules folder in the ContentBox module or install from the download manager.

Change Log
-----------------
* Version 1.0 - Initial Release